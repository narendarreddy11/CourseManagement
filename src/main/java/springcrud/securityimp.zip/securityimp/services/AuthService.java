package springcrud.securityimp.services;

import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import springcrud.securityimp.Dtos.LoginRequestDto;
import springcrud.securityimp.Dtos.LoginResponseDto;
import springcrud.securityimp.Dtos.SignUpRequestDto;
import springcrud.securityimp.Dtos.SignUpResponseDto;
import springcrud.securityimp.Repo.UserRepo;
import springcrud.securityimp.model.User;

@Service
@RequiredArgsConstructor
@Component
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final UserDetailsServiceImp userDetailsService;
    private final JwtService jwtService;
    private final UserRepo userRepo;
    private final PasswordEncoder passwordEncoder;

    public LoginResponseDto login(LoginRequestDto loginRequestDto) {
        Authentication authentication=authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequestDto.getUsername(), loginRequestDto.getPassword()));

        UserDetails userDetails = userDetailsService.loadUserByUsername(loginRequestDto.getUsername());
        String token = jwtService.generateToken(userDetails);
        User user = userRepo.findByUsername(loginRequestDto.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));


        return new LoginResponseDto(
                token,
                userDetails.getUsername(),
                user.getRole(),
                user.getEmail()
        );


    }
    public SignUpResponseDto register(SignUpRequestDto req) {
        if (userRepo.findByUsername(req.getUsername()).isPresent()) {
            throw new RuntimeException("Username already exists");
        }

        User user = User.builder()
                .username(req.getUsername())
                .password(passwordEncoder.encode(req.getPassword()))
                .email(req.getEmail())
                .role("ROLE_USER")
                .build();

        userRepo.save(user);

        return new SignUpResponseDto("User registered successfully", user.getUsername());
    }


}
