package springcrud.securityimp.Dtos;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class SignUpRequestDto {
    private String username;
    private String password;
    private String email;
}
